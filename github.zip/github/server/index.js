const {createPool} = require('mysql2');

const pool = createPool({
    host:"localhost",
    user:"root",
    password: "root",
    database:"agrilearn",
    connectionLimit:10
})

pool.query(`insert into cropprediction values(85,58,41,21.77046169,80.31964408,7.038096361,226.6555374,'rice');`,(err,result,fields)=>{
    if(err){
        return console.log(err);
    }
    return console.log(result);
})



