import React from 'react';
import '../../App.css';
// import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import CropPrediction from './CropPrediction';
export default function Services() {
  return (
  <><h1 className='services'>SERVICES</h1>
  </>
  );
}