export const MenuItems2 = [
    {
      title: 'Hydroponics',
      path: '/marketing',
      cName: 'dropdown-link'
    },
    {
      title: 'Aquaponics',
      path: '/consulting',
      cName: 'dropdown-link'
    },
    {
      title: 'Organic',
      path: '/design',
      cName: 'dropdown-link'
    },
    {
      title: 'Inorganic',
      path: '/development',
      cName: 'dropdown-link'
    }
  ];