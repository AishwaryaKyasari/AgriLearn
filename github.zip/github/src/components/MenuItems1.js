export const MenuItems1 = [
    {
      title: 'Crop Prediction',
      path: '/cropprediction', 
      cName: 'dropdown-link'
    },
    {
      title: 'Seeds Information',
      path: '/seedsinforamtion',
      cName: 'dropdown-link'
    },
    {
      title: 'Crop information',
      path: '/design',
      cName: 'dropdown-link'
    },
    // {
    //   title: 'Development',
    //   path: '/development',
    //   cName: 'dropdown-link'
    // }
  ];